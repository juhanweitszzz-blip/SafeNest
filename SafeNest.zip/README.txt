SafeNest — parental-control app prototype

OPEN ON ANDROID OR IPHONE
1. Extract SafeNest.zip in your Files app.
2. Open SafeNest.html in your browser (or open the HTML file from your file manager).
3. Use the sidebar to explore the interactive prototype.

IMPORTANT LIMITATIONS
This is a self-contained interactive web prototype, not a native Android APK or iOS IPA.
It does not enforce restrictions on a device, collect real location/app usage, send alerts,
authenticate users, connect to a database, or send remote lock/unlock commands.
All statuses are deliberately marked Demo, Pending Permission, or Unsupported where relevant.
A real production build requires a backend and native Android/iOS apps with platform permissions.
iOS app distribution requires Apple's signing/distribution process; Android APKs must be built
and signed. Extracting a ZIP cannot itself install a native app on both platforms.
